#bin/sh
rm -f iconv*.lib iconv*.dll
